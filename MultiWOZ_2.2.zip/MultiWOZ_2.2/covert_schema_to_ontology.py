import json

informable_slots = {
    "taxi": ["leave", "destination", "departure", "arrive"],
    "police": [],
    "hospital": ["department"],
    "hotel": ["type", "parking", "pricerange", "internet", "stay", "day", "people", "area", "stars", "name"],
    "attraction": ["area", "type", "name"],
    "train": ["destination", "day", "arrive", "departure", "people", "leave"],
    "restaurant": ["food", "pricerange", "area", "name", "time", "day", "people"]
}

ontology = {}

with open('schema.json', 'r') as f:
    domains = json.loads(f.read())

for domain in domains:
    domain_name = domain['service_name']
    slots_in_ontology = set()
    for slot in domain['slots']:
        slot_name = slot['name'].split('-')[1]
        if slot_name.startswith('book'):
            slot_name = slot_name[4:]
        elif slot_name == 'leaveat':
            slot_name = 'leave'
        elif slot_name == 'arriveby':
            slot_name = 'arrive'

        if domain_name == 'bus' or slot_name in informable_slots[domain_name]:
            if slot['is_categorical']:
                ontology[domain_name + '-' + slot_name] = slot['possible_values']
            else:
                ontology[domain_name + '-' + slot_name] = []

with open('ontology.json', 'w') as f:
    json.dump(ontology, f, indent=2)

